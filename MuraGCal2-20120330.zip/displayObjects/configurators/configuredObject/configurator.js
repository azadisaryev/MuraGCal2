function initMuraGCalConfigurator(data){
		
	initConfigurator(
		data,
		{
			url:'../plugins/MuraGCal2/displayObjects/configurators/configuredObject/configurator.cfm',
			pars:'',
			title: 'MuraGCal2 Configuratorinator',
			init: function(){},
			destroy: function(){},
			validate: function(){
				return true;	
				}
		}
	);
			
	return true;
}